document.getElementById("first_button").addEventListener("click",function(){
    window.location.href = "location_selection.html";
});